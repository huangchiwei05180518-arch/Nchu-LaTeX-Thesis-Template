# NCHU Thesis Format and Example_Latex (2025.04)
Please refer to Registration Division of Academic Affairs Office for "NCHU Thesis/Dissertation Format".
(http://oaa.nchu.edu.tw/en-us/rs-form/download-list.82)

# Instructions
This template has been created using [Overleaf](https://www.overleaf.com/) .

1. Before using, go to Manu/Setting/Compiler and set it to XeLatex.
   
2. The corresponding instructions are as follows:
   chapters/L.00-01.Cover.tex: Cover
   chapters/L.00-02.Acknowledgement.tex: Acknowledgements(Optional)
   chapters/L.00-03.Abstract.tex: Abstract(Chinese and English, Keyword)
   chapters/L.01.Introduction.tex: Texts(L01-05)
   chapters/L.09.Appendix.tex: Appendix

3. The oral defense evaluation page has already been set up in main.tex. Please scan it into a PDF file and name it Evaluation_eng.pdf. Upload it to the attachments folder to replace the existing file.

4. The table of contents, list of tables, and list of figures are already set up in main.tex.

5. The References section is set up in main.tex. Please update the references in the REF.bib file.
