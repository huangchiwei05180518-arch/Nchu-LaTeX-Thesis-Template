# 國立中興大學論文Latex模板 (2025.04)
論文項目及次序，依「國立中興大學學位論文格式規範」規定撰寫
(http://oaa.nchu.edu.tw/zh-tw/rs-form/download-list.82)

# 使用說明
此模板使用 [Overleaf](https://www.overleaf.com/) 編輯

1. 使用前請在 Manu/Setting/Compiler 設定為 XeLatex
   
2. 對應說明如下:
   chapters/L.00-01.Cover.tex: 書名頁/封面
   chapters/L.00-02.Acknowledgement.tex: 誌謝辭(非必備)
   chapters/L.00-03.Abstract.tex: 摘要(中英文，需含關鍵字)
   chapters/L.01.Introduction.tex: 正文(L01-05, 請依需求修改)
   chapters/L.09.Appendix.tex: 附錄

3. 審核頁已在 main.tex 設定，請掃描成PDF檔並命名為Evaluation.pdf
   上傳至 attachments 覆蓋檔案即可
   
4. 目次、表目次、圖目次已在 main.tex 設定

5. 參考文獻已在 main.tex 設定，請將書目更新至 REF.bib 
